export let dados = {
    cliente: [],
    categoria: [],
    produto: [],
    vendedor: [],
    pedido: []
}